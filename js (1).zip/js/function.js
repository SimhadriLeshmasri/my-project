function greet(name) {
    return "Hello, " + name + "!";
}

document.getElementById("demo").innerHTML = greet("Alice");
