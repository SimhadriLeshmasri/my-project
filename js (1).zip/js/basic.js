<script>
    document.getElementById("demo").innerHTML = "Hello, JavaScript!";
</script>
